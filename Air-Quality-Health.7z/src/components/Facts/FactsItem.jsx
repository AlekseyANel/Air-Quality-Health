import React from 'react';
import './Facts.scss';

const FactsItem = () => {
    return (
        <div>
           
        </div>


    )
}
export default FactsItem;